// Defoul setting

// move up
const moveUp = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('move-up-active')
    }
  })
})
document.querySelectorAll('.move-up').forEach((element) => {
  moveUp.observe(element)
})
// move up end

// from left
const fromLeft = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('from-left-active')
    }
  })
})
document.querySelectorAll(`.from-left`).forEach((element) => {
  fromLeft.observe(element)
})

// from left ends

// from right
const fromRight = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add(`from-right-active`)
    }
  })
})
document.querySelectorAll(`.from-right`).forEach((element) => {
  fromRight.observe(element)
})

//   from right ends

// Header

const header = document.querySelector('.header')

window.addEventListener('scroll', () => {
  if (window.scrollY > 0) {
    header.classList.add('scrolled')
  } else {
    header.classList.remove('scrolled')
  }
})
// Navigation

const navShowBtn = document.querySelector(`.navigation-show-btn`)
const navHideBtn = document.querySelector(`.navigation-hide-btn`)
const navigation = document.querySelector(`.navigation`)

function navShow() {
  navigation.classList.remove('navigation-hide')
  navigation.classList.add('navigation-show')
  navShowBtn.classList.add(`navigation-btn-hide`)
  navHideBtn.classList.add('navigation-btn-show')
  navHideBtn.classList.remove(`navigation-btn-hide`)
  navShowBtn.addEventListener('animationend', () => {})
}
function navHide() {
  navigation.classList.remove('navigation-show')
  navigation.classList.add('navigation-hide')
  navHideBtn.classList.add(`navigation-btn-hide`)
  navShowBtn.classList.remove(`navigation-btn-hide`)
  navShowBtn.classList.add(`navigation-btn-show`)
  navigation.addEventListener('animationend', (e) => {
    if (e.animationName === 'navigationHide') {
      navigation.classList.remove('navigation-hide')
    }
  })
}
navShowBtn.addEventListener('click', () => {
  navShow()
})
navHideBtn.addEventListener('click', () => {
  navHide()
})
// hero section

// Text
const heroDescrText = `Building robust, scalable web applications with modern technologies.
  Focused on clean code, exceptional user experiences, and continuous growth`

//   DOM
const heroDescr = document.querySelector(`.hero-descr`)
const speed = 100
let heroDescrLength = 0

function typeEffect() {
  if (heroDescrLength < heroDescrText.length) {
    heroDescr.textContent += heroDescrText[heroDescrLength]
    heroDescrLength++
    typeTimeout = setTimeout(typeEffect, speed)
  } else {
    clearTimeout(typeEffect)
  }
}
typeEffect()
// hero section ends

// Contact form

const form = document.querySelector('form')

const message = {
  loading: () => {
    document.querySelector(`.icon-send`).classList.add(`icon-send`)
  },
  success: () => {
    document.querySelector(`.cnt-send-btn`).textContent = 'Your message is sent'
  },
  failure: () => {
    document.querySelector(`.cnt-send-btn`).textContent =
      'Try to contact with me via email'
  },
}

form.addEventListener('submit', (e) => {
  e.preventDefault()

  const clientName = form.clientname.value
  const clientEmail = form.clientemail.value
  const clientMessage = form.message.value

  // 💥 NEW: Call your backend (Netlify function)
  fetch('/.netlify/functions/api', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: `
Client's name: ${clientName}
Client's email: ${clientEmail}
Client's message: ${clientMessage}
`,
    }),
  })
    .then(() => message.success())
    .catch(() => message.failure())
    .finally(() => {
      function messageResponse() {
        form.clientname.value = ''
        form.clientemail.value = ''
        form.message.value = ''
        document.querySelector(
          '.cnt-send-btn'
        ).innerHTML = `Submit <i class="fa-solid fa-arrow-right icon-send"></i>`
      }
      setTimeout(messageResponse, 5000)
    })
})
