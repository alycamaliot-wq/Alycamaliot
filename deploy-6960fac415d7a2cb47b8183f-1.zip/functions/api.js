import express from 'express'
import serverless from 'serverless-http'

const app = express()

app.use(express.json())

app.post('/', async (req, res) => {
  const message = req.body.message

  if (!message) {
    return res.json({ error: 'No message' })
  }

  const token = process.env.TG_TOKEN
  const chatId = process.env.TG_CHAT_ID

  const url = `https://api.telegram.org/bot${token}/sendMessage`

  await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
    }),
  })

  res.json({ success: true })
})

export const handler = serverless(app)
