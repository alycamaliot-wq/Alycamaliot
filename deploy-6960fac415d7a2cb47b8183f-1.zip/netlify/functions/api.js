export const handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, body: 'Method Not Allowed' }
    }

    const body = JSON.parse(event.body)

    const message = body.message

    const TELEGRAM_TOKEN = process.env.TG_TOKEN
    const CHAT_ID = process.env.CHAT_ID

    // sanity check
    if (!TELEGRAM_TOKEN || !CHAT_ID) {
      return { statusCode: 500, body: 'Env vars missing' }
    }

    // Telegram API call
    const telegramRes = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text: message,
        }),
      }
    )

    if (!telegramRes.ok) {
      const text = await telegramRes.text()
      return { statusCode: 500, body: `Telegram failed: ${text}` }
    }

    return { statusCode: 200, body: JSON.stringify({ success: true }) }
  } catch (err) {
    console.error(err)
    return { statusCode: 500, body: `Server error: ${err.message}` }
  }
}
